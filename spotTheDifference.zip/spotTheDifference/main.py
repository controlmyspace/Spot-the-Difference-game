import pygame
import os
import time

pygame.init()

LEVELS = 5
IMAGE_PATH = "levels"
WINDOW_SIZE = (800, 400)
HALF_WIDTH = WINDOW_SIZE[0] // 2
DIFFERENCES_PER_LEVEL = {1: 4, 2: 5, 3: 6, 4: 7, 5: 8}
COORDINATES_PER_LEVEL = {1: [(560, 153), (492, 251), (651, 349), (767, 324)],
                         2: [(772, 40), (581, 40), (788, 360), (478, 371), (568, 340)],
                         3: [(521, 229), (721, 258), (567, 159), (719, 153), (701, 218), (777, 239)],
                         4: [(637, 285), (534, 41), (430, 368), (727, 255), (752, 172), (645, 74), (680, 34)],
                         5: [(621, 131), (621, 129), (406, 290), (505, 288), (752, 339), (702, 265), (552, 316),
                             (510, 227)]}

screen = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption("Spot the Difference! (on the right image)")


def load_image(name):
    # Load image from levels folder to be displayed on screen
    img = pygame.image.load(os.path.join(IMAGE_PATH, name))
    return pygame.transform.scale(img, (HALF_WIDTH, WINDOW_SIZE[1]))


def show_winner_screen(player1_time, player2_time):
    # Display winner of round
    screen.fill((255, 255, 255))
    game_font = pygame.font.Font(None, 30)

    if player1_time < player2_time:
        winner_text = (f"Player 1 took ({format_time(player1_time)})s. Player 2 took ({format_time(player2_time)})s."
                       f"PLAYER 1 WINS!")
    elif player2_time < player1_time:
        winner_text = (f"Player 1 took ({format_time(player1_time)})s. Player 2 took ({format_time(player2_time)})s."
                       f"PLAYER 2 WINS!")
    else:
        winner_text = f"Both players took ({format_time(player1_time)})s. IT'S A TIE!"

    text = game_font.render(winner_text, True, (0, 0, 0))

    screen.blit(text, (WINDOW_SIZE[0] // 2 - text.get_width() // 2, 150))

    pygame.display.flip()
    pygame.time.delay(3000)


def format_time(seconds):
    # format time for player timer
    minutes = seconds // 60
    seconds = seconds % 60
    return f"{minutes:02}:{seconds:02}"


def main():
    clock = pygame.time.Clock()
    game_font = pygame.font.Font(None, 30)
    running = True
    level = 1
    player_turn = 1
    player1_time = 0
    player2_time = 0

    while level <= LEVELS and running:
        original_image = load_image(f"level{level}.png")
        modified_image = load_image(f"level{level}_diff.png")
        found_differences = 0
        required_differences = DIFFERENCES_PER_LEVEL[level]
        differences_coordinates = COORDINATES_PER_LEVEL[level]
        different_areas = [pygame.Rect(x - 60, y - 40, 120, 80) for x, y in differences_coordinates]
        found_coordinates = []

        # Start the timer for the first player
        start_time = time.time()

        playing = True
        while playing:
            # Split screen, show original image on the left and modified on the right
            screen.fill((255, 255, 255))
            screen.blit(original_image, (0, 0))
            screen.blit(modified_image, (HALF_WIDTH, 0))

            # Draw white borders around images
            pygame.draw.rect(screen, (255, 255, 255), (0, 0, HALF_WIDTH, WINDOW_SIZE[1]), 5)
            pygame.draw.rect(screen, (255, 255, 255), (HALF_WIDTH, 0, HALF_WIDTH, WINDOW_SIZE[1]), 5)

            # Display game details
            player_text = game_font.render(f"Player {player_turn}", True, (0, 0, 0))
            timer_text = game_font.render(format_time(player1_time if player_turn == 1 else player2_time), True,
                                          (255, 0, 0))
            differences_text = game_font.render(f"{found_differences}/{required_differences}", True, (0, 0, 0))

            screen.blit(player_text, (10, 10))
            screen.blit(timer_text, (HALF_WIDTH - timer_text.get_width() // 2, 10))
            screen.blit(differences_text, (WINDOW_SIZE[0] - differences_text.get_width() - 10, 10))

            # Draw found spots on each image
            for coord in found_coordinates:
                pygame.draw.circle(screen, (0, 255, 0), (coord[0] - HALF_WIDTH, coord[1]), 40, 2)
                pygame.draw.circle(screen, (0, 255, 0), coord, 40, 2)

            pygame.display.flip()

            if player_turn == 1:
                player1_time = int(time.time() - start_time)
            else:
                player2_time = int(time.time() - start_time)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    playing = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos
                    for area in different_areas:
                        # If player clicks on a difference spot, show circle
                        if area.collidepoint(x, y):
                            found_coordinates.append(area.center)
                            found_differences += 1
                    if found_differences >= required_differences:
                        # Switch turn
                        if player_turn == 1:
                            player_turn = 2
                        elif player_turn == 2:  # all players have played, go to next level
                            show_winner_screen(player1_time, player2_time)
                            player_turn = 1
                            playing = False
                        start_time = time.time()
                        found_differences = 0
                        found_coordinates = []
            clock.tick(30)
        level += 1  # Move to next level

    pygame.quit()


if __name__ == "__main__":
    main()
